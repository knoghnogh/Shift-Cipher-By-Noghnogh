﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

/*

    Kaled Noghnogh
    June 5th 2020
    asisstance by Bassem Noghnogh
*/

namespace SubstitutionCipher_KALEDNOGHNOGH
{
    class Program
    {
        static void Main(string[] args)
        {
            Write("The string you would like to encode: ");
            string encoded = encode(ReadLine());
            WriteLine("The string encoded: " + encoded);
            WriteLine();
            
            Write("The string you would like to decode: ");
            string decoded = decode(ReadLine());
            WriteLine("The string decoded: " + decoded);

            ReadKey();
        }

        public static string encode(string input)
        {
            input = input.ToLower();
            char[] inputArray = input.ToCharArray();
            char[] outputArray = input.ToCharArray();
            for (int j = 0; j < input.Length; j++)
            {
                for (int i = 0; i < 24; i++)
                {
                    if (inputArray[j] == plaintext[i])
                    {
                        outputArray[j] = ciphertext[i];
                    }
                }
            }
            string output = new string(outputArray);
            return output;
        }

        public static string decode(string input)
        {
            input = input.ToLower();
            char[] inputArray = input.ToCharArray();
            char[] outputArray = input.ToCharArray();
            for (int j = 0; j < input.Length; j++)
            {
                for (int i = 0; i < 24; i++)
                {
                    if (inputArray[j] == ciphertext[i])
                    {
                        outputArray[j] = plaintext[i];
                    }
                }
            }
            string output = new string(outputArray);
            return output;
        }

        static char[] plaintext =
            {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'w', 'x', 'y', 'z' };
        static char[] ciphertext =
            {'z', 'y', 'x', 'w', 't', 's', 'r', 'q', 'p', 'o', 'n', 'm', 'l', 'k', 'j', 'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a' };
    }
}
